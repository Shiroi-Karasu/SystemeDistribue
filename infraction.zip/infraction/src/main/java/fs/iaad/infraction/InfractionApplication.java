package fs.iaad.infraction;

import fs.iaad.infraction.entities.Infraction;
import fs.iaad.infraction.repositories.InfractionRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Random;

@SpringBootApplication
public class InfractionApplication {

    public static void main(String[] args) {
        SpringApplication.run(InfractionApplication.class, args);
    }

    @Bean
    CommandLineRunner start(InfractionRepository infractionRepository){
        return args -> {
            int i, nbrInfractions = new Random().nextInt(5, 15);
            for (i = 0; i < nbrInfractions; i++) {
                int vitesseMaximale = new Random().nextInt(150, 214);
                infractionRepository.save(Infraction.builder()
                                .vitesseMaximale(vitesseMaximale)
                                .vitesseMinimale(new Random().nextInt(80, vitesseMaximale + 1))
                                .montant(new Random().nextDouble(100, 600))
                                .build());
            }
        };
    }
}
