package fs.iaad.infraction.mappers;

import fs.iaad.infraction.dto.InfractionRequestDTO;
import fs.iaad.infraction.dto.InfractionResponseDTO;
import fs.iaad.infraction.entities.Infraction;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

@Component
public class InfractionMapper {
    public InfractionResponseDTO fromInfraction(Infraction infraction) {
        InfractionResponseDTO infractionResponseDTO = new InfractionResponseDTO();
        BeanUtils.copyProperties(infraction, infractionResponseDTO);
        return infractionResponseDTO;
    }

    public Infraction fromInfractionDto(InfractionRequestDTO infractionRequestDTO) {
        if (infractionRequestDTO.getVitesseMinimale() > infractionRequestDTO.getVitesseMaximale()) throw new RuntimeException("Il semble que la vitesse minimale est supérieure à celle maximale...Ce qui est bizard!");
        return Infraction.builder()
                .montant(infractionRequestDTO.getMontant())
                .vitesseMinimale(infractionRequestDTO.getVitesseMinimale())
                .vitesseMaximale(infractionRequestDTO.getVitesseMaximale())
                .build();
    }

    public InfractionResponseDTO updateInfractionDTO(Infraction oldInfraction, InfractionRequestDTO infractionRequestDTO) {
        if (infractionRequestDTO.getVitesseMaximale() != null && infractionRequestDTO.getVitesseMinimale() != null) {
            if (infractionRequestDTO.getVitesseMinimale() > infractionRequestDTO.getVitesseMaximale())
                throw new RuntimeException("Il semble que la vitesse minimale est supérieure à celle maximale...Ce qui est bizard!");
        }
        if (infractionRequestDTO.getVitesseMaximale() == null && infractionRequestDTO.getVitesseMinimale() != null) {
            if (infractionRequestDTO.getVitesseMinimale() > oldInfraction.getVitesseMaximale())
                throw new RuntimeException("Il semble que la vitesse minimale est supérieure à celle maximale...Ce qui est bizard!");
        }
        if (infractionRequestDTO.getVitesseMinimale() == null && infractionRequestDTO.getVitesseMaximale() != null) {
            if (oldInfraction.getVitesseMinimale() > infractionRequestDTO.getVitesseMaximale())
                throw new RuntimeException("Il semble que la vitesse minimale est supérieure à celle maximale...Ce qui est bizard!");
        }
        if (infractionRequestDTO.getVitesseMaximale() != null)
            if (!infractionRequestDTO.getVitesseMaximale().equals(oldInfraction.getVitesseMaximale()))
                oldInfraction.setVitesseMaximale(infractionRequestDTO.getVitesseMaximale());
        if (infractionRequestDTO.getVitesseMinimale() != null)
            if (!infractionRequestDTO.getVitesseMinimale().equals(oldInfraction.getVitesseMinimale()))
                oldInfraction.setVitesseMinimale(infractionRequestDTO.getVitesseMinimale());
        if (infractionRequestDTO.getMontant() != null)
            if (!infractionRequestDTO.getMontant().equals(oldInfraction.getMontant()))
                oldInfraction.setMontant(infractionRequestDTO.getMontant());

        return fromInfraction(oldInfraction);
    }
}
