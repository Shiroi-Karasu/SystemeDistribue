package fs.iaad.infraction.web;

import fs.iaad.infraction.dto.InfractionRequestDTO;
import fs.iaad.infraction.dto.InfractionResponseDTO;
import fs.iaad.infraction.services.InfractionService;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class GraphQlInfractionService {
    private final InfractionService infractionService;

    public GraphQlInfractionService(InfractionService infractionService) {
        this.infractionService = infractionService;
    }

    @QueryMapping
    public List<InfractionResponseDTO> infractions() {return infractionService.allInfractions();}

    @QueryMapping
    public InfractionResponseDTO infraction(@Argument String id) {return infractionService.findInfractionById(Long.valueOf(id));}

    @MutationMapping
    public InfractionResponseDTO nouvelleInfraction(@Argument InfractionRequestDTO infraction) {return infractionService.addInfraction(infraction);}

    @MutationMapping
    public InfractionResponseDTO updateInfraction(@Argument String id, @Argument InfractionRequestDTO infraction) {
        return infractionService.updateInfraction(Long.valueOf(id), infraction);
    }

    @MutationMapping
    public boolean deleteInfraction(@Argument String id) {
        infractionService.deleteInfraction(Long.valueOf(id));
        return true;
    }
}
