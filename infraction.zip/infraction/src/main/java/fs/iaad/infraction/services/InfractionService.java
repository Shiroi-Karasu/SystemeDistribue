package fs.iaad.infraction.services;

import fs.iaad.infraction.dto.InfractionRequestDTO;
import fs.iaad.infraction.dto.InfractionResponseDTO;

import java.util.List;

public interface InfractionService {
    List<InfractionResponseDTO> allInfractions();
    InfractionResponseDTO findInfractionById(Long id);
    InfractionResponseDTO addInfraction(InfractionRequestDTO infractionDTO);
    InfractionResponseDTO updateInfraction(Long id, InfractionRequestDTO infractionDTO);
    void deleteInfraction(Long id);
}
