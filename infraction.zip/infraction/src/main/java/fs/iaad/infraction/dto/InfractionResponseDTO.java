package fs.iaad.infraction.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class InfractionResponseDTO {
    Long id;
    Integer vitesseMinimale;
    Integer vitesseMaximale;
    Double montant;
}
