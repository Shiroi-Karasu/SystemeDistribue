package fs.iaad.infraction.web;

import fs.iaad.infraction.dto.InfractionRequestDTO;
import fs.iaad.infraction.dto.InfractionResponseDTO;
import fs.iaad.infraction.services.InfractionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class RestInfractionService {
    private final InfractionService infractionService;

    public RestInfractionService(InfractionService infractionService) {
        this.infractionService = infractionService;
    }

    @GetMapping("/infractions")
    public List<InfractionResponseDTO> infractions() {
        return infractionService.allInfractions();
    }

    @GetMapping("/infractions/{id}")
    public InfractionResponseDTO infraction(@PathVariable Long id) {
        return infractionService.findInfractionById(id);
    }

    @PutMapping("/infractions/{id}")
    public InfractionResponseDTO update(@PathVariable Long id, @RequestBody InfractionRequestDTO infractionDTO) {
        return infractionService.updateInfraction(id, infractionDTO);
    }

    @PostMapping("/infractions/addInfraction")
    public InfractionResponseDTO save(@RequestBody InfractionRequestDTO infractionDTO) {
        return infractionService.addInfraction(infractionDTO);
    }

    @DeleteMapping("/infractions/{id}")
    public void delete(@PathVariable Long id) {infractionService.deleteInfraction(id);}
}
