package fs.iaad.infraction.services;

import fs.iaad.infraction.dto.InfractionRequestDTO;
import fs.iaad.infraction.dto.InfractionResponseDTO;
import fs.iaad.infraction.entities.Infraction;
import fs.iaad.infraction.mappers.InfractionMapper;
import fs.iaad.infraction.repositories.InfractionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class InfractionServiceImpl implements InfractionService{
    private final InfractionRepository infractionRepository;
    private final InfractionMapper infractionMapper;

    public InfractionServiceImpl(InfractionRepository infractionRepository, InfractionMapper infractionMapper) {
        this.infractionRepository = infractionRepository;
        this.infractionMapper = infractionMapper;
    }
    @Override
    public List<InfractionResponseDTO> allInfractions() {
        List<InfractionResponseDTO> infractionsDTO = new ArrayList<>();
        List<Infraction> infractions = infractionRepository.findAll();

        for (Infraction infraction: infractions) {
            infractionsDTO.add(infractionMapper.fromInfraction(infraction));
        }
        return infractionsDTO;
    }

    @Override
    public InfractionResponseDTO findInfractionById(Long id) {
        return infractionMapper.fromInfraction(infractionRepository.findById(id).orElseThrow(()-> new RuntimeException("Cette infraction est introuvable.")));
    }

    @Override
    public InfractionResponseDTO addInfraction(InfractionRequestDTO infractionDTO) {
        Infraction nouvelleInfraction = infractionMapper.fromInfractionDto(infractionDTO);
        infractionRepository.save(nouvelleInfraction);
        return infractionMapper.fromInfraction(nouvelleInfraction);
    }

    @Override
    public InfractionResponseDTO updateInfraction(Long id, InfractionRequestDTO infractionDTO) {
        Infraction oldInfraction = infractionRepository.findById(id).orElseThrow(()-> new RuntimeException("Infraction introuvable"));
        return infractionMapper.updateInfractionDTO(oldInfraction, infractionDTO);
    }

    @Override
    public void deleteInfraction(Long id) {
        infractionRepository.deleteById(id);
    }
}
