package fs.iaad.infraction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfractionApplicationTests {

	@Test
	void contextLoads() {
	}

}
