package fs.iaad.radar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RadarApplicationTests {

	@Test
	void contextLoads() {
	}

}
