package fs.iaad.radar.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class RadarRequestDTO {
    Integer vitesseMaximale;
    Double longitude;
    Double Latitude;
}
