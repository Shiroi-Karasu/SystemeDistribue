package fs.iaad.radar.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Data
public class Vehicule {
    Long id;
    String numeroMatriculation;
    String marque;
    Integer puissanceFiscale;
    String modele;
}
