package fs.iaad.radar.feign;

import fs.iaad.radar.models.Proprietaire;
import fs.iaad.radar.models.Vehicule;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.hateoas.PagedModel;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "SERVICE-IMMATRICULATION")//, url = "localhost:1230")
public interface ImmatriculationRestClient {
    @GetMapping(path = "/api/proprietaires/{id}")
    Proprietaire getProprietaireById(@PathVariable(name = "id") Long id);

    @GetMapping(path = "/api/proprietaires")
    List<Proprietaire> getAllProprietaires();

    @GetMapping(path = "/api/vehicules/{id}")
    Vehicule getVehiculeById(@PathVariable(name = "id") Long id);

    @GetMapping(path = "/api/vehicules")
    List<Vehicule> getAllVehicules();
}
