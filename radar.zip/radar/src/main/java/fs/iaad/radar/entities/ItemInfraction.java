package fs.iaad.radar.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import fs.iaad.radar.models.Infraction;
import fs.iaad.radar.models.Proprietaire;
import fs.iaad.radar.models.Vehicule;
import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@ToString
public class ItemInfraction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    Date date;
    Long numeroRadar;
    String matriculeVehicule;
    Integer vitesseVehicule;
    Integer vitesseMaximale;
    Double montant;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @ManyToOne
    Radar radar;
    @Transient
    Infraction infraction;
    Long idInfraction;
    @Transient
    Vehicule vehicule;
    Long idVehicule;
}
