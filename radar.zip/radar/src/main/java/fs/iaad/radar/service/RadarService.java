package fs.iaad.radar.service;

import fs.iaad.radar.dto.RadarRequestDTO;
import fs.iaad.radar.dto.RadarResponseDTO;

import java.util.List;

public interface RadarService {
    List<RadarResponseDTO> allRadars();
    RadarResponseDTO findRadarById(Long id);
    RadarResponseDTO addRadar(RadarRequestDTO radarDTO);
    RadarResponseDTO updateRadar(Long id, RadarRequestDTO radarDTO);
    void deleteRadar(Long id);
}
