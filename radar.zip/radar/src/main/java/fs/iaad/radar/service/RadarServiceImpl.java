package fs.iaad.radar.service;

import fs.iaad.radar.dto.RadarRequestDTO;
import fs.iaad.radar.dto.RadarResponseDTO;
import fs.iaad.radar.entities.Radar;
import fs.iaad.radar.mappers.RadarMapper;
import fs.iaad.radar.repositories.RadarRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class RadarServiceImpl implements RadarService{
    private final RadarRepository radarRepository;
    private final RadarMapper radarMapper;

    public RadarServiceImpl(RadarRepository radarRepository, RadarMapper radarMapper) {
        this.radarRepository = radarRepository;
        this.radarMapper = radarMapper;
    }


    @Override
    public List<RadarResponseDTO> allRadars() {
        List<RadarResponseDTO> radarsDTO = new ArrayList<>();
        List<Radar> radars = radarRepository.findAll();

        for (Radar radar: radars) {
            radarsDTO.add(radarMapper.fromRadar(radar));
        }
        return radarsDTO;
    }

    @Override
    public RadarResponseDTO findRadarById(Long id) {
        return radarMapper.fromRadar(radarRepository.findById(id).orElseThrow(()-> new RuntimeException("Ce radar est introuvable.")));
    }

    @Override
    public RadarResponseDTO addRadar(RadarRequestDTO radarDTO) {
        Radar radar = radarMapper.fromRadarDto(radarDTO);
        radarRepository.save(radar);
        return radarMapper.fromRadar(radar);
    }

    @Override
    public RadarResponseDTO updateRadar(Long id, RadarRequestDTO radarDTO) {
        Radar oldRadar = radarRepository.findById(id).orElseThrow(()->new RuntimeException("Radar introuvable."));
        return radarMapper.updateRadarDTO(oldRadar, radarDTO);
    }

    @Override
    public void deleteRadar(Long id) {
        radarRepository.deleteById(id);
    }
}
