package fs.iaad.radar.mappers;

import fs.iaad.radar.dto.RadarRequestDTO;
import fs.iaad.radar.dto.RadarResponseDTO;
import fs.iaad.radar.entities.Radar;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

@Component
public class RadarMapper {
    public RadarResponseDTO fromRadar(Radar radar) {
        RadarResponseDTO radarResponseDTO = new RadarResponseDTO();
        BeanUtils.copyProperties(radar, radarResponseDTO);
        return radarResponseDTO;
    }

    public Radar fromRadarDto(RadarRequestDTO radarRequestDTO) {
        return Radar.builder()
                .Latitude(radarRequestDTO.getLatitude())
                .longitude(radarRequestDTO.getLongitude())
                .vitesseMaximale(radarRequestDTO.getVitesseMaximale())
                .build();
    }

    public RadarResponseDTO updateRadarDTO(Radar oldRadar, RadarRequestDTO radarRequestDTO) {
        if (radarRequestDTO.getLatitude() != null)
            if (!radarRequestDTO.getLatitude().equals(oldRadar.getLatitude()))
                oldRadar.setLatitude(radarRequestDTO.getLatitude());
        if (radarRequestDTO.getLongitude() != null)
            if (!radarRequestDTO.getLongitude().equals(oldRadar.getLongitude()))
                oldRadar.setLongitude(radarRequestDTO.getLongitude());
        if (radarRequestDTO.getVitesseMaximale() != null)
            if (!radarRequestDTO.getVitesseMaximale().equals(oldRadar.getVitesseMaximale()))
                oldRadar.setVitesseMaximale(radarRequestDTO.getVitesseMaximale());

        return fromRadar(oldRadar);
    }
}
