package fs.iaad.radar.service;

import fs.iaad.radar.dto.ItemInfractionRequestDTO;
import fs.iaad.radar.dto.ItemInfractionResponseDTO;

import java.util.List;

public interface ItemInfractionService {
    List<ItemInfractionResponseDTO> allItemInfractions();
    ItemInfractionResponseDTO findItemInfractionById(Long id);
    ItemInfractionResponseDTO addItemInfraction(ItemInfractionRequestDTO itemInfractionDTO);
    void deleteItemInfraction(Long id);
}
