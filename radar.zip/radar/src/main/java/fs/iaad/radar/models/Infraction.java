package fs.iaad.radar.models;

import lombok.Data;

@Data
public class Infraction {
    Long id;
    Integer vitesseMinimale;
    Integer vitesseMaximale;
    Double montant;
}
