package fs.iaad.radar.web;


public class GraphQlRadarService {
}
