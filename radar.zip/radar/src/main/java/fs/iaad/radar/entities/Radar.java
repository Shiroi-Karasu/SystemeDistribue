package fs.iaad.radar.entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.Collection;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class Radar {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    Integer vitesseMaximale;
    Double longitude;
    Double Latitude;
    @OneToMany(mappedBy = "radar")
    Collection<ItemInfraction> infractionsDetectees;
}
