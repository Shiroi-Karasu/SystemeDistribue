package fs.iaad.radar;

import fs.iaad.radar.entities.ItemInfraction;
import fs.iaad.radar.entities.Radar;
import fs.iaad.radar.feign.ImmatriculationRestClient;
import fs.iaad.radar.feign.InfractionRestClient;
import fs.iaad.radar.models.Infraction;
import fs.iaad.radar.models.Vehicule;
import fs.iaad.radar.repositories.ItemInfractionRepository;
import fs.iaad.radar.repositories.RadarRepository;
import fs.iaad.radar.stub.RadarServiceGrpc;
import fs.iaad.radar.stub.RadarServiceOuterClass;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

import java.util.Date;
import java.util.List;
import java.util.Random;

@SpringBootApplication
@EnableFeignClients
public class RadarApplication {

    public static void main(String[] args) {
        SpringApplication.run(RadarApplication.class, args);
    }

    @Bean
    CommandLineRunner start(RadarRepository radarRepository, ItemInfractionRepository itemInfractionRepository,
                            ImmatriculationRestClient immatriculationRestClient, InfractionRestClient infractionRestClient) {
        return args -> {
            int i, nbrRadar = new Random().nextInt(1, 6);
            for (i = 0; i < nbrRadar; i++)
                radarRepository.save(Radar.builder()
                                .vitesseMaximale(new Random().nextInt(50,100))
                                .Latitude(new Random().nextDouble(-90,91))
                                .longitude(new Random().nextDouble(-180, 181))
                        .build());

            List<Vehicule> vehicules = immatriculationRestClient.getAllVehicules();
            List<Infraction> infractions = infractionRestClient.getAllInfractions();

            List<Radar> nosRadar = radarRepository.findAll();

            //créer un client GRPC
            ManagedChannel client = ManagedChannelBuilder.forAddress("localhost", 1233)
                    .usePlaintext()//mode negotiation
                    .build();

            for (Radar r:nosRadar) {
                RadarServiceGrpc.RadarServiceBlockingStub blockingStub = RadarServiceGrpc.newBlockingStub(client);
                for (Vehicule v:vehicules) {
                    if (r.getVitesseMaximale() <= v.getPuissanceFiscale()) {
                        RadarServiceOuterClass.DepassementRequest requette = RadarServiceOuterClass.DepassementRequest.newBuilder()
                                .setVitesseMaximale(r.getVitesseMaximale())
                                .setPuissanceFiscale(v.getPuissanceFiscale())
                                .build();
                        RadarServiceOuterClass.DepassementResponse reponse = blockingStub.nouveauDepassement(requette);//j'atteds jusqu'à ce que je reçoie la réponse
                        int vitesseVehicule = reponse.getVitesseVehicule();
                        for (Infraction infraction: infractions) {
                            if (vitesseVehicule >= infraction.getVitesseMinimale() && vitesseVehicule <= infraction.getVitesseMaximale()) {
                                itemInfractionRepository.save(ItemInfraction.builder()
                                                .date(new Date())
                                                .numeroRadar(r.getId())
                                                .matriculeVehicule(v.getNumeroMatriculation())
                                                .vitesseVehicule(vitesseVehicule)
                                                .vitesseMaximale(r.getVitesseMaximale())
                                                .montant(infraction.getMontant())
                                                .radar(r)
                                                .idInfraction(infraction.getId())
                                                .infraction(infraction)
                                                .idVehicule(v.getId())
                                                .vehicule(v)
                                                .build());
                                break;
                            }
                        }
                    }
                }
            }
        };
    }
}
