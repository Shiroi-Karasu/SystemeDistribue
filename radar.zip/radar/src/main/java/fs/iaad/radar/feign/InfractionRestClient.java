package fs.iaad.radar.feign;

import fs.iaad.radar.models.Infraction;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "SERVICE-INFRACTION")//, url = "localhost:1231")
public interface InfractionRestClient {
    @GetMapping(path = "/api/infractions/{id}")
    Infraction getInfractionById(@PathVariable(name = "id") Long id);

    @GetMapping(path = "/api/infractions")
    List<Infraction> getAllInfractions();
}
