package fs.iaad.radar.models;

import jakarta.persistence.OneToMany;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class Proprietaire {
    Long id;
    String nom;
    Date dateNaissance;
    String mail;
}
