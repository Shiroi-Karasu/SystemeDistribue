package fs.iaad.radar.mappers;

import fs.iaad.radar.dto.ItemInfractionRequestDTO;
import fs.iaad.radar.dto.ItemInfractionResponseDTO;
import fs.iaad.radar.entities.ItemInfraction;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class ItemInfractionMapper {
    public ItemInfractionResponseDTO fromItemInfraction(ItemInfraction itemInfraction) {
        ItemInfractionResponseDTO itemInfractionResponseDTO = new ItemInfractionResponseDTO();
        BeanUtils.copyProperties(itemInfraction, itemInfractionResponseDTO);
        return itemInfractionResponseDTO;
    }

    public ItemInfraction fromItemInfractionDto(ItemInfractionRequestDTO itemInfractionDTO) {
        return ItemInfraction.builder()
                    .date(itemInfractionDTO.getDate() == null ? new Date():itemInfractionDTO.getDate())
                    .numeroRadar(itemInfractionDTO.getNumeroRadar())
                    .matriculeVehicule(itemInfractionDTO.getMatriculeVehicule())
                    .vitesseVehicule(itemInfractionDTO.getVitesseVehicule())
                    .idInfraction(itemInfractionDTO.getIdInfraction())
                    .montant(itemInfractionDTO.getMontant())
                    .idVehicule(itemInfractionDTO.getIdVehicule())
                    .build();
    }
}
