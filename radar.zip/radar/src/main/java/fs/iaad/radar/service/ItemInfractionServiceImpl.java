package fs.iaad.radar.service;

import fs.iaad.radar.dto.ItemInfractionRequestDTO;
import fs.iaad.radar.dto.ItemInfractionResponseDTO;
import fs.iaad.radar.entities.ItemInfraction;
import fs.iaad.radar.mappers.ItemInfractionMapper;
import fs.iaad.radar.repositories.ItemInfractionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class ItemInfractionServiceImpl implements ItemInfractionService {
    private final ItemInfractionRepository itemInfractionRepository;
    private final ItemInfractionMapper itemInfractionMapper;

    public ItemInfractionServiceImpl(ItemInfractionRepository itemInfractionRepository, ItemInfractionMapper itemInfractionMapper) {
        this.itemInfractionRepository = itemInfractionRepository;
        this.itemInfractionMapper = itemInfractionMapper;
    }

    @Override
    public List<ItemInfractionResponseDTO> allItemInfractions() {
        List<ItemInfractionResponseDTO> itemInfractionsDTO = new ArrayList<>();
        List<ItemInfraction> itemInfractions = itemInfractionRepository.findAll();

        for (ItemInfraction i: itemInfractions) {
            itemInfractionsDTO.add(itemInfractionMapper.fromItemInfraction(i));
        }

        return itemInfractionsDTO;
    }

    @Override
    public ItemInfractionResponseDTO findItemInfractionById(Long id) {
        return itemInfractionMapper.fromItemInfraction(itemInfractionRepository.findById(id).orElseThrow(()->new RuntimeException("Item infraction introuvable.")));
    }

    @Override
    public ItemInfractionResponseDTO addItemInfraction(ItemInfractionRequestDTO itemInfractionDTO) {
        ItemInfraction itemInfraction = itemInfractionMapper.fromItemInfractionDto(itemInfractionDTO);
        itemInfractionRepository.save(itemInfraction);
        return itemInfractionMapper.fromItemInfraction(itemInfraction);
    }

    @Override
    public void deleteItemInfraction(Long id) {
        itemInfractionRepository.deleteById(id);
    }
}
