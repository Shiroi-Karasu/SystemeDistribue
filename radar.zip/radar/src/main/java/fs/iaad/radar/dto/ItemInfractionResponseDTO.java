package fs.iaad.radar.dto;

import lombok.*;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class ItemInfractionResponseDTO {
    Long id;
    Date date;
    Long numeroRadar;
    String matriculeVehicule;
    Integer vitesseVehicule;
    Integer vitesseMaximale;
    Double montant;
    Long idVehicule;
    Long idInfraction;
}
