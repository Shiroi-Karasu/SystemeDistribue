package fs.iaad.radar.web;

import fs.iaad.radar.dto.ItemInfractionRequestDTO;
import fs.iaad.radar.dto.ItemInfractionResponseDTO;
import fs.iaad.radar.dto.RadarRequestDTO;
import fs.iaad.radar.dto.RadarResponseDTO;
import fs.iaad.radar.service.ItemInfractionService;
import fs.iaad.radar.service.RadarService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class RestRadarService {
    private final RadarService radarService;
    private final ItemInfractionService itemInfractionService;

    public RestRadarService(RadarService radarService, ItemInfractionService itemInfractionService) {
        this.radarService = radarService;
        this.itemInfractionService = itemInfractionService;
    }

    @GetMapping("/radars")
    public List<RadarResponseDTO> radars() {
        return radarService.allRadars();
    }

    @GetMapping("/itemInfractions")
    public List<ItemInfractionResponseDTO> itemInfractions() {
        return itemInfractionService.allItemInfractions();
    }

    @GetMapping("/radars/{id}")
    public RadarResponseDTO radar(@PathVariable Long id) {
        return radarService.findRadarById(id);
    }

    @GetMapping("/itemInfractions/{id}")
    public ItemInfractionResponseDTO itemInfraction(@PathVariable Long id) {
        return itemInfractionService.findItemInfractionById(id);
    }

    @PutMapping("/radars/{id}")
    public RadarResponseDTO update(@PathVariable Long id, @RequestBody RadarRequestDTO radarDTO) {
        return radarService.updateRadar(id, radarDTO);
    }

    @PostMapping("/radars/addradar")
    public RadarResponseDTO save(@RequestBody RadarRequestDTO radarDTO) {
        return radarService.addRadar(radarDTO);
    }

    @PostMapping("/itemInfractions/addItemInfraction")
    public ItemInfractionResponseDTO save(@RequestBody ItemInfractionRequestDTO itemInfractionDTO) {
        return itemInfractionService.addItemInfraction(itemInfractionDTO);
    }

    @DeleteMapping("/radars/{id}")
    public void deleteRadar(@PathVariable Long id) {radarService.deleteRadar(id);}

    @DeleteMapping("/itemInfractions/{id}")
    public void deleteItemInfraction(@PathVariable Long id) {itemInfractionService.deleteItemInfraction(id);}
}
