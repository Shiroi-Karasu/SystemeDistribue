package fs.iaad.radar.repositories;

import fs.iaad.radar.entities.ItemInfraction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ItemInfractionRepository extends JpaRepository<ItemInfraction, Long> {
}
