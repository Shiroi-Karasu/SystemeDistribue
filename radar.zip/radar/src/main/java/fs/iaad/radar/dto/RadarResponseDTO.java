package fs.iaad.radar.dto;

import fs.iaad.radar.entities.ItemInfraction;
import lombok.*;

import java.util.Collection;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class RadarResponseDTO {
    Long id;
    Integer vitesseMaximale;
    Double longitude;
    Double Latitude;
    Collection<ItemInfraction> infractionsDetectees;
}
