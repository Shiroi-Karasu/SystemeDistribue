package fs.iaad.immatriculation.dto;

import lombok.*;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class ProprietaireRequestDTO {
    String nom;
    Date dateNaissance;
    String mail;
}
