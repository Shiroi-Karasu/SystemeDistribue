package fs.iaad.immatriculation.web;

import fs.iaad.immatriculation.dto.ProprietaireRequestDTO;
import fs.iaad.immatriculation.dto.ProprietaireResponseDTO;
import fs.iaad.immatriculation.dto.VehiculeRequestDTO;
import fs.iaad.immatriculation.dto.VehiculeResponseDTO;
import fs.iaad.immatriculation.service.ProprietaireService;
import fs.iaad.immatriculation.service.VehiculeService;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class GraphQLImmatriculationService {
    private final ProprietaireService proprietaireService;
    private final VehiculeService vehiculeService;

    public GraphQLImmatriculationService(ProprietaireService proprietaireService, VehiculeService vehiculeService) {
        this.proprietaireService = proprietaireService;
        this.vehiculeService = vehiculeService;
    }

    @QueryMapping
    public List<ProprietaireResponseDTO> proprietaires() {
        return proprietaireService.allProprietaires();
    }

    @QueryMapping
    public ProprietaireResponseDTO proprietaire(@Argument String id) {
        return proprietaireService.findProprietaireById(Long.valueOf(id));
    }

    @QueryMapping
    public List<VehiculeResponseDTO> vehiculesByProprietaire(@Argument String id) {
        return vehiculeService.vehiculesParProprietaire(Long.valueOf(id));
    }

    @QueryMapping
    public List<VehiculeResponseDTO> vehicules() {
        return vehiculeService.allVehicules();
    }

    @QueryMapping
    public VehiculeResponseDTO vehicule(@Argument String id) {
        return vehiculeService.findVehiculeById(Long.valueOf(id));
    }

    @MutationMapping
    public ProprietaireResponseDTO nouveauProprietaire(@Argument ProprietaireRequestDTO proprietaire) {
        return proprietaireService.addProprietaire(proprietaire);
    }

    @MutationMapping
    public ProprietaireResponseDTO updateProprietaire(@Argument String id, @Argument ProprietaireRequestDTO proprietaire) {
        return proprietaireService.updateProprietaire(Long.valueOf(id), proprietaire);
    }

    @MutationMapping
    public boolean deleteProprietaire(@Argument String id) {
        List<VehiculeResponseDTO> sesVehicule = vehiculeService.vehiculesParProprietaire(Long.valueOf(id));
        for (VehiculeResponseDTO vehiculeDTO: sesVehicule) {
            vehiculeService.deleteVehicule(vehiculeDTO.getId());
        }
        proprietaireService.deleteProprietaire(Long.valueOf(id));
        return true;
    }

    @MutationMapping
    public VehiculeResponseDTO nouvelleVehicule(@Argument String id, @Argument VehiculeRequestDTO vehicule) {
        return vehiculeService.addVehicule(Long.valueOf(id), vehicule);
    }

    @MutationMapping
    public VehiculeResponseDTO updateVehicule(@Argument String id, @Argument VehiculeRequestDTO vehicule) {
        return vehiculeService.updateVehicule(Long.valueOf(id), vehicule);
    }

    @MutationMapping
    public boolean deleteVehicule(@Argument String id) {
        vehiculeService.deleteVehicule(Long.valueOf(id));
        return true;    
    }
}
