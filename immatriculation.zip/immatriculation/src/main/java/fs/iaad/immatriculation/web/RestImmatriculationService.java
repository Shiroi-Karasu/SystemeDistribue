package fs.iaad.immatriculation.web;

import fs.iaad.immatriculation.dto.ProprietaireRequestDTO;
import fs.iaad.immatriculation.dto.ProprietaireResponseDTO;
import fs.iaad.immatriculation.dto.VehiculeRequestDTO;
import fs.iaad.immatriculation.dto.VehiculeResponseDTO;
import fs.iaad.immatriculation.service.ProprietaireService;
import fs.iaad.immatriculation.service.VehiculeService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class RestImmatriculationService {
    private final ProprietaireService proprietaireService;
    private final VehiculeService vehiculeService;

    public RestImmatriculationService(ProprietaireService proprietaireService, VehiculeService vehiculeService) {
        this.proprietaireService = proprietaireService;
        this.vehiculeService = vehiculeService;
    }

    @GetMapping("/proprietaires")
    public List<ProprietaireResponseDTO> proprietaires() {
        return proprietaireService.allProprietaires();
    }

    @GetMapping("/vehicules")
    public List<VehiculeResponseDTO> vehicules() {
        return vehiculeService.allVehicules();
    }
    //public String vehicules() {return vehiculeService.mapOfVehicules();}

    @GetMapping("/proprietaires/{id}")
    public ProprietaireResponseDTO proprietaire(@PathVariable Long id) {
        return proprietaireService.findProprietaireById(id);
    }

    @GetMapping("/proprietaires/{id}/véhicules")
    public List<VehiculeResponseDTO> vehiculesByProprietaire(@PathVariable Long id) {
        return vehiculeService.vehiculesParProprietaire(id);
    }

    @GetMapping("/véhicules/{id}")
    public VehiculeResponseDTO vehicule(@PathVariable Long id) {
        return vehiculeService.findVehiculeById(id);
    }

    @PutMapping("/proprietaires/{id}")
    public ProprietaireResponseDTO update(@PathVariable Long id, @RequestBody ProprietaireRequestDTO proprietaireDTO) {
        return proprietaireService.updateProprietaire(id, proprietaireDTO);
    }

    @PutMapping("/véhicules/{id}")
    public VehiculeResponseDTO update(@PathVariable Long id, @RequestBody VehiculeRequestDTO vehiculeDTO) {
        return vehiculeService.updateVehicule(id, vehiculeDTO);
    }

    @PostMapping("/proprietaires/addProprietaire")
    public ProprietaireResponseDTO save(@RequestBody ProprietaireRequestDTO proprietaireDTO) {
        return proprietaireService.addProprietaire(proprietaireDTO);
    }

    @PostMapping("/proprietaires/{id}/addVehicule")
    public VehiculeResponseDTO save(@PathVariable Long id, @RequestBody VehiculeRequestDTO vehiculeDTO) {
        return vehiculeService.addVehicule(id, vehiculeDTO);
    }

    @DeleteMapping("/proprietaires/{id}")
    public void delete(@PathVariable Long id) {
        List<VehiculeResponseDTO> sesVehicule = vehiculeService.vehiculesParProprietaire(id);
        for (VehiculeResponseDTO vehiculeDTO: sesVehicule) {
            vehiculeService.deleteVehicule(vehiculeDTO.getId());
        }
        proprietaireService.deleteProprietaire(id);
    }

    @DeleteMapping("/véhicules/{id}")
    public void deleteVehicule(@PathVariable Long id) {vehiculeService.deleteVehicule(id);}
}
