package fs.iaad.immatriculation.service;

import fs.iaad.immatriculation.dto.VehiculeRequestDTO;
import fs.iaad.immatriculation.dto.VehiculeResponseDTO;

import java.util.List;

public interface VehiculeService {
    List<VehiculeResponseDTO> allVehicules();
    List<VehiculeResponseDTO> vehiculesParProprietaire(Long id);
    VehiculeResponseDTO findVehiculeById(Long id);
    VehiculeResponseDTO addVehicule(Long id, VehiculeRequestDTO vehiculeDTO);
    VehiculeResponseDTO updateVehicule(Long id, VehiculeRequestDTO vehiculeRequestDTO);
    void deleteVehicule(Long id);
}
