package fs.iaad.immatriculation.service;

import fs.iaad.immatriculation.dto.ProprietaireRequestDTO;
import fs.iaad.immatriculation.dto.ProprietaireResponseDTO;
import fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass;

import java.util.List;

public interface ProprietaireService {
    List<ProprietaireResponseDTO> allProprietaires();
    List<ImmatriculationServiceOuterClass.ProprietairesResponse> allProprietairesResponse(List<ProprietaireResponseDTO> proprietairesDto);
    ProprietaireResponseDTO findProprietaireById(Long id);
    ProprietaireResponseDTO addProprietaire(ProprietaireRequestDTO proprietaireDTO);
    ProprietaireResponseDTO updateProprietaire(Long id, ProprietaireRequestDTO proprietaireDTO);
    void deleteProprietaire(Long id);
}
