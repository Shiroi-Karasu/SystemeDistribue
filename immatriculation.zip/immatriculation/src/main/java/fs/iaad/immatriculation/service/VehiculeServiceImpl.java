package fs.iaad.immatriculation.service;

import fs.iaad.immatriculation.dto.VehiculeRequestDTO;
import fs.iaad.immatriculation.dto.VehiculeResponseDTO;
import fs.iaad.immatriculation.entities.Proprietaire;
import fs.iaad.immatriculation.entities.Vehicule;
import fs.iaad.immatriculation.mappers.VehiculeMapper;
import fs.iaad.immatriculation.repositories.ProprietaireRepository;
import fs.iaad.immatriculation.repositories.VehiculeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional
public class VehiculeServiceImpl implements VehiculeService{
    VehiculeRepository vehiculeRepository;
    VehiculeMapper vehiculeMapper;
    ProprietaireRepository proprietaireRepository;

    public VehiculeServiceImpl(VehiculeRepository vehiculeRepository, VehiculeMapper vehiculeMapper, ProprietaireRepository proprietaireRepository) {
        this.vehiculeRepository = vehiculeRepository;
        this.vehiculeMapper = vehiculeMapper;
        this.proprietaireRepository = proprietaireRepository;
    }

    @Override
    public List<VehiculeResponseDTO> allVehicules() {
        List<VehiculeResponseDTO> vehiculesDTO = new ArrayList<>();
        List<Vehicule> vehicules = vehiculeRepository.findAll();

        for (Vehicule v: vehicules) {
            vehiculesDTO.add(vehiculeMapper.fromVehicule(v));
        }

        return vehiculesDTO;
    }

    @Override
    public List<VehiculeResponseDTO> vehiculesParProprietaire(Long id) {
        List<VehiculeResponseDTO> vehiculesParProprietaire = new ArrayList<>();
        List<Vehicule> vehicules = vehiculeRepository.findByProprietaireId(id);
        for (Vehicule v: vehicules)
            vehiculesParProprietaire.add(vehiculeMapper.fromVehicule(v));
        return vehiculesParProprietaire;
    }

    @Override
    public VehiculeResponseDTO findVehiculeById(Long id) {
        return vehiculeMapper.fromVehicule(vehiculeRepository.findById(id).orElseThrow(() -> new RuntimeException("Véhicule introuvable.")));
    }

    @Override
    public VehiculeResponseDTO addVehicule(Long id, VehiculeRequestDTO vehiculeDTO) {
        Proprietaire proprietaire = proprietaireRepository.findById(id).orElseThrow(()->new RuntimeException("Propriétaire introuvable."));
        Vehicule vehicule = vehiculeMapper.fromVehiculeDto(vehiculeDTO);
        vehicule.setProprietaire(proprietaire);
        vehiculeRepository.save(vehicule);
        if (proprietaire.getVehiculesPossedees() != null)
            proprietaire.getVehiculesPossedees().add(vehicule);
        else {
            List<Vehicule> nouvellesVehicules = new ArrayList<>();
            nouvellesVehicules.add(vehicule);
            proprietaire.setVehiculesPossedees(nouvellesVehicules);
        }
        return vehiculeMapper.fromVehicule(vehicule);
    }

    @Override
    public VehiculeResponseDTO updateVehicule(Long id, VehiculeRequestDTO vehiculeRequestDTO) {
        Vehicule oldVehicule = vehiculeRepository.findById(id).orElseThrow(() -> new RuntimeException("Véhicule introuvable."));
        return vehiculeMapper.updateVehicule(oldVehicule, vehiculeRequestDTO);
    }

    @Override
    public void deleteVehicule(Long id) {
        vehiculeRepository.deleteById(id);
    }
}
