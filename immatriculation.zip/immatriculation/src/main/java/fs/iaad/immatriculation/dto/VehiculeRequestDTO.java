package fs.iaad.immatriculation.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class VehiculeRequestDTO {
    String numeroMatriculation;
    String marque;
    Integer puissanceFiscale;
    String modele;
}
