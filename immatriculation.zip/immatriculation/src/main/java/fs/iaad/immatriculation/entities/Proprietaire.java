package fs.iaad.immatriculation.entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class Proprietaire {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    String nom;
    Date dateNaissance;
    String mail;
    @OneToMany(mappedBy = "proprietaire")
    List<Vehicule> vehiculesPossedees;
}
