package fs.iaad.immatriculation.web;

import org.apache.cxf.Bus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CXFSoapWebServiceConfig {
    private final Bus bus;
    private final SoapImmatriculationService soapImmatriculationService;

    public CXFSoapWebServiceConfig(Bus bus, SoapImmatriculationService soapImmatriculationService) {
        this.bus = bus;
        this.soapImmatriculationService = soapImmatriculationService;
    }

    @Bean
    public EndpointImpl endpoint() {
        EndpointImpl endpoint = new EndpointImpl(bus, soapImmatriculationService);
        endpoint.publish("/ImmatriculationSoapService");
        return endpoint;
    }

}
