package fs.iaad.immatriculation;

import fs.iaad.immatriculation.entities.Proprietaire;
import fs.iaad.immatriculation.entities.Vehicule;
import fs.iaad.immatriculation.repositories.ProprietaireRepository;
import fs.iaad.immatriculation.repositories.VehiculeRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.*;
import java.util.stream.Stream;

@SpringBootApplication
public class ImmatriculationApplication {

    public static void main(String[] args) {
        SpringApplication.run(ImmatriculationApplication.class, args);
    }

    public static String generateMatricule() {
        StringBuilder matricule = new StringBuilder();
        Random random = new Random();

        for (int i = 0; i < 8; i++) {
            int digit = random.nextInt(10);
            matricule.append(digit);
        }

        return matricule.toString();
    }

    public static Date genererDateDeNaissanceAleatoire() {
        Calendar calendar = new GregorianCalendar();
        Random random = new Random();
        int annee = random.nextInt(2003 - 1950 + 1) + 1950;
        int mois = random.nextInt(12);
        int jourMax = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        int jour = random.nextInt(jourMax) + 1;

        calendar.set(Calendar.YEAR, annee);
        calendar.set(Calendar.MONTH, mois);
        calendar.set(Calendar.DAY_OF_MONTH, jour);

        return calendar.getTime();
    }

    @Bean
    CommandLineRunner start(ProprietaireRepository proprietaireRepository, VehiculeRepository vehiculeRepository){
        List<Proprietaire> proprietaires = new ArrayList<>();
        String[] marques = {"Ford", "Kia", "Jeep", "Jaguar", "Renault"};
        Map<String, String> modeles = new HashMap<>();
        modeles.put("Transit", marques[0]);//Pickup
        modeles.put("Mustang", marques[0]);//Car
        modeles.put("GT-2017", marques[0]);//Car
        modeles.put("F-Max", marques[0]);//Truck
        modeles.put("K5", marques[1]);//Car
        modeles.put("Carnival", marques[1]);//Car
        modeles.put("Granbird", marques[1]);//Bus
        modeles.put("Bongo", marques[1]);//Pickup
        modeles.put("Compass", marques[2]);//Car
        modeles.put("Gladiator", marques[2]);//Pickup
        modeles.put("Avenger", marques[2]);//Car
        modeles.put("Wrangler", marques[2]);//Car
        modeles.put("XE", marques[3]);//Car
        modeles.put("F-Type", marques[3]);//Car
        modeles.put("E-Pace", marques[3]);//Car
        modeles.put("F-Pace", marques[3]);//Car
        modeles.put("Master", marques[4]);//Van
        modeles.put("C", marques[4]);//Truck
        modeles.put("K", marques[4]);//Truk
        modeles.put("Alaskan", marques[4]);//Pickup

        List<Vehicule> vehicules = new ArrayList<>();
        byte[] bytearray = new byte[256];
        for (Map.Entry<String,String> entry:
             modeles.entrySet()) {
            new Random().nextBytes(bytearray);
            vehicules.add(Vehicule.builder()
                    .marque(entry.getValue())
                    .modele(entry.getKey())
                    .numeroMatriculation(generateMatricule())
                    .puissanceFiscale(100 + new Random().nextInt(0, 114))
                    .build());
        }

        return args -> {
            Stream.of("Kawtar", "Sanae", "Oumaima", "Houda", "Assia", "Lamia").forEach(nomProprietaire -> proprietaires.add(Proprietaire.builder()
                              .nom(nomProprietaire)
                              .dateNaissance(genererDateDeNaissanceAleatoire())
                              .mail(nomProprietaire + "@gmail.com")
                              .build()));

            for (Proprietaire proprietaire: proprietaires) {
                int nbrVehiculesPossedees = new Random().nextInt(1, 4);
                int nbrVehicules = vehicules.size();
                List<Vehicule> choisie = new ArrayList<>();
                Proprietaire p = proprietaireRepository.save(proprietaire);
                for (int i = 0; i < nbrVehiculesPossedees; i++) {
                    Vehicule vehicule = vehicules.get(new Random().nextInt(0, nbrVehicules));
                    while (choisie.contains(vehicule))
                        vehicule = vehicules.get(new Random().nextInt(0, nbrVehicules));
                    choisie.add(vehicule);
                    vehicule.setProprietaire(p);
                    vehiculeRepository.save(vehicule);
                    if(p.getVehiculesPossedees() != null)
                        (p.getVehiculesPossedees()).add(vehicule);
                    else {
                        List<Vehicule> mesVehicules = new ArrayList<>();
                        mesVehicules.add(vehicule);
                        p.setVehiculesPossedees(mesVehicules);
                    }
                }
            }
      };
    }
}
