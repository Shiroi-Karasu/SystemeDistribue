package fs.iaad.immatriculation.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class VehiculeResponseDTO {
    Long id;
    String numeroMatriculation;
    String marque;
    Integer puissanceFiscale;
    String modele;
}
