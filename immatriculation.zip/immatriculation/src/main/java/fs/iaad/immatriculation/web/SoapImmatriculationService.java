package fs.iaad.immatriculation.web;

import fs.iaad.immatriculation.dto.ProprietaireRequestDTO;
import fs.iaad.immatriculation.dto.ProprietaireResponseDTO;
import fs.iaad.immatriculation.dto.VehiculeRequestDTO;
import fs.iaad.immatriculation.dto.VehiculeResponseDTO;
import fs.iaad.immatriculation.service.ProprietaireService;
import fs.iaad.immatriculation.service.VehiculeService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import org.springframework.stereotype.Component;

import java.util.List;

@Component // ni controlleur no REST Controlleur mais un simple composant
@WebService(name = "ImmatriculationSoapService")
public class SoapImmatriculationService {
    private final ProprietaireService proprietaireService;
    private final VehiculeService vehiculeService;

    public SoapImmatriculationService(ProprietaireService proprietaireService, VehiculeService vehiculeService) {
        this.proprietaireService = proprietaireService;
        this.vehiculeService = vehiculeService;
    }

    @WebMethod
    public List<ProprietaireResponseDTO> proprietaires() {
        return proprietaireService.allProprietaires();
    }

    @WebMethod
    public ProprietaireResponseDTO proprietaire(@WebParam(name = "id") String id) {
        return proprietaireService.findProprietaireById(Long.valueOf(id));
    }

    @WebMethod
    public ProprietaireResponseDTO nouveauProprietaire(@WebParam(name = "proprietaire") ProprietaireRequestDTO proprietaire) {
        return proprietaireService.addProprietaire(proprietaire);
    }

    @WebMethod
    public ProprietaireResponseDTO updateProprietaire(@WebParam(name = "id") String id, @WebParam(name = "proprietaire") ProprietaireRequestDTO proprietaire) {
        return proprietaireService.updateProprietaire(Long.valueOf(id), proprietaire);
    }

    @WebMethod
    public boolean deleteProprietaire(@WebParam(name = "id") String id) {
        List<VehiculeResponseDTO> sesVehicule = vehiculeService.vehiculesParProprietaire(Long.valueOf(id));
        for (VehiculeResponseDTO vehiculeDTO: sesVehicule) {
            vehiculeService.deleteVehicule(vehiculeDTO.getId());
        }
        proprietaireService.deleteProprietaire(Long.valueOf(id));
        return true;
    }

    @WebMethod
    public List<VehiculeResponseDTO> vehicules() {
        return vehiculeService.allVehicules();
    }

    @WebMethod
    public VehiculeResponseDTO vehicule(@WebParam(name = "id") String id) {
        return vehiculeService.findVehiculeById(Long.valueOf(id));
    }

    @WebMethod
    public VehiculeResponseDTO nouvelleVehicule(@WebParam String id, @WebParam VehiculeRequestDTO vehicule) {
        return vehiculeService.addVehicule(Long.valueOf(id), vehicule);
    }

    @WebMethod
    public VehiculeResponseDTO updateVehicule(@WebParam String id, @WebParam VehiculeRequestDTO vehicule) {
        return vehiculeService.updateVehicule(Long.valueOf(id), vehicule);
    }

    @WebMethod
    public boolean deleteVehicule(@WebParam String id) {
        vehiculeService.deleteVehicule(Long.valueOf(id));
        return true;
    }
}
