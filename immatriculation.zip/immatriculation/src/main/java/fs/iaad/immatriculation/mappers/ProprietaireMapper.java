package fs.iaad.immatriculation.mappers;

import fs.iaad.immatriculation.dto.ProprietaireRequestDTO;
import fs.iaad.immatriculation.dto.ProprietaireResponseDTO;
import fs.iaad.immatriculation.entities.Proprietaire;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

@Component
public class ProprietaireMapper {
    public ProprietaireResponseDTO fromProprietaire(Proprietaire proprietaire) {
        ProprietaireResponseDTO proprietaireResponseDTO = new ProprietaireResponseDTO();
        BeanUtils.copyProperties(proprietaire, proprietaireResponseDTO);
        return proprietaireResponseDTO;
    }

    public Proprietaire fromProprietaireDto(ProprietaireRequestDTO proprietaireRequestDTO) {
        return Proprietaire.builder()
                .nom(proprietaireRequestDTO.getNom())
                .dateNaissance(proprietaireRequestDTO.getDateNaissance())
                .mail(proprietaireRequestDTO.getMail())
                .build();
    }

    public ProprietaireResponseDTO updateProprietaireDTO(Proprietaire oldProprietaire, ProprietaireRequestDTO proprietaireRequestDTO) {
        if (proprietaireRequestDTO.getNom() != null)
            if (!proprietaireRequestDTO.getNom().equals(oldProprietaire.getNom()))
                oldProprietaire.setNom(proprietaireRequestDTO.getNom());
        if (proprietaireRequestDTO.getDateNaissance() != null)
            if (proprietaireRequestDTO.getDateNaissance() != oldProprietaire.getDateNaissance())
                oldProprietaire.setDateNaissance(proprietaireRequestDTO.getDateNaissance());
        if (proprietaireRequestDTO.getMail() != null)
            if (!proprietaireRequestDTO.getMail().equals(oldProprietaire.getMail()))
                oldProprietaire.setMail(proprietaireRequestDTO.getMail());

        return fromProprietaire(oldProprietaire);
    }
}
