package fs.iaad.immatriculation.stub;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: ImmatriculationService.proto")
public final class ImmatriculationServiceGrpc {

  private ImmatriculationServiceGrpc() {}

  public static final String SERVICE_NAME = "ImmatriculationService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesRequest,
      fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesResponse> getProprietairesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "proprietaires",
      requestType = fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesRequest.class,
      responseType = fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesRequest,
      fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesResponse> getProprietairesMethod() {
    io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesRequest, fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesResponse> getProprietairesMethod;
    if ((getProprietairesMethod = ImmatriculationServiceGrpc.getProprietairesMethod) == null) {
      synchronized (ImmatriculationServiceGrpc.class) {
        if ((getProprietairesMethod = ImmatriculationServiceGrpc.getProprietairesMethod) == null) {
          ImmatriculationServiceGrpc.getProprietairesMethod = getProprietairesMethod = 
              io.grpc.MethodDescriptor.<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesRequest, fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "ImmatriculationService", "proprietaires"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new ImmatriculationServiceMethodDescriptorSupplier("proprietaires"))
                  .build();
          }
        }
     }
     return getProprietairesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId,
      fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> getProprietaireMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "proprietaire",
      requestType = fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId.class,
      responseType = fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId,
      fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> getProprietaireMethod() {
    io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId, fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> getProprietaireMethod;
    if ((getProprietaireMethod = ImmatriculationServiceGrpc.getProprietaireMethod) == null) {
      synchronized (ImmatriculationServiceGrpc.class) {
        if ((getProprietaireMethod = ImmatriculationServiceGrpc.getProprietaireMethod) == null) {
          ImmatriculationServiceGrpc.getProprietaireMethod = getProprietaireMethod = 
              io.grpc.MethodDescriptor.<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId, fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "ImmatriculationService", "proprietaire"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new ImmatriculationServiceMethodDescriptorSupplier("proprietaire"))
                  .build();
          }
        }
     }
     return getProprietaireMethod;
  }

  private static volatile io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireRequest,
      fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> getNouveauProprietaireMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "nouveauProprietaire",
      requestType = fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireRequest.class,
      responseType = fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireRequest,
      fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> getNouveauProprietaireMethod() {
    io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireRequest, fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> getNouveauProprietaireMethod;
    if ((getNouveauProprietaireMethod = ImmatriculationServiceGrpc.getNouveauProprietaireMethod) == null) {
      synchronized (ImmatriculationServiceGrpc.class) {
        if ((getNouveauProprietaireMethod = ImmatriculationServiceGrpc.getNouveauProprietaireMethod) == null) {
          ImmatriculationServiceGrpc.getNouveauProprietaireMethod = getNouveauProprietaireMethod = 
              io.grpc.MethodDescriptor.<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireRequest, fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "ImmatriculationService", "nouveauProprietaire"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new ImmatriculationServiceMethodDescriptorSupplier("nouveauProprietaire"))
                  .build();
          }
        }
     }
     return getNouveauProprietaireMethod;
  }

  private static volatile io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireUpdateRequest,
      fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> getUpdateProprietaireMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "updateProprietaire",
      requestType = fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireUpdateRequest.class,
      responseType = fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireUpdateRequest,
      fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> getUpdateProprietaireMethod() {
    io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireUpdateRequest, fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> getUpdateProprietaireMethod;
    if ((getUpdateProprietaireMethod = ImmatriculationServiceGrpc.getUpdateProprietaireMethod) == null) {
      synchronized (ImmatriculationServiceGrpc.class) {
        if ((getUpdateProprietaireMethod = ImmatriculationServiceGrpc.getUpdateProprietaireMethod) == null) {
          ImmatriculationServiceGrpc.getUpdateProprietaireMethod = getUpdateProprietaireMethod = 
              io.grpc.MethodDescriptor.<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireUpdateRequest, fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "ImmatriculationService", "updateProprietaire"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireUpdateRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new ImmatriculationServiceMethodDescriptorSupplier("updateProprietaire"))
                  .build();
          }
        }
     }
     return getUpdateProprietaireMethod;
  }

  private static volatile io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId,
      fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireEtat> getDeleteProprietaireMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "deleteProprietaire",
      requestType = fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId.class,
      responseType = fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireEtat.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId,
      fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireEtat> getDeleteProprietaireMethod() {
    io.grpc.MethodDescriptor<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId, fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireEtat> getDeleteProprietaireMethod;
    if ((getDeleteProprietaireMethod = ImmatriculationServiceGrpc.getDeleteProprietaireMethod) == null) {
      synchronized (ImmatriculationServiceGrpc.class) {
        if ((getDeleteProprietaireMethod = ImmatriculationServiceGrpc.getDeleteProprietaireMethod) == null) {
          ImmatriculationServiceGrpc.getDeleteProprietaireMethod = getDeleteProprietaireMethod = 
              io.grpc.MethodDescriptor.<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId, fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireEtat>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "ImmatriculationService", "deleteProprietaire"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireEtat.getDefaultInstance()))
                  .setSchemaDescriptor(new ImmatriculationServiceMethodDescriptorSupplier("deleteProprietaire"))
                  .build();
          }
        }
     }
     return getDeleteProprietaireMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ImmatriculationServiceStub newStub(io.grpc.Channel channel) {
    return new ImmatriculationServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ImmatriculationServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new ImmatriculationServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ImmatriculationServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new ImmatriculationServiceFutureStub(channel);
  }

  /**
   */
  public static abstract class ImmatriculationServiceImplBase implements io.grpc.BindableService {

    /**
     */
    public void proprietaires(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesRequest request,
        io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getProprietairesMethod(), responseObserver);
    }

    /**
     */
    public void proprietaire(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId request,
        io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getProprietaireMethod(), responseObserver);
    }

    /**
     */
    public void nouveauProprietaire(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireRequest request,
        io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getNouveauProprietaireMethod(), responseObserver);
    }

    /**
     */
    public void updateProprietaire(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireUpdateRequest request,
        io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getUpdateProprietaireMethod(), responseObserver);
    }

    /**
     */
    public void deleteProprietaire(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId request,
        io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireEtat> responseObserver) {
      asyncUnimplementedUnaryCall(getDeleteProprietaireMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getProprietairesMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesRequest,
                fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesResponse>(
                  this, METHODID_PROPRIETAIRES)))
          .addMethod(
            getProprietaireMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId,
                fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse>(
                  this, METHODID_PROPRIETAIRE)))
          .addMethod(
            getNouveauProprietaireMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireRequest,
                fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse>(
                  this, METHODID_NOUVEAU_PROPRIETAIRE)))
          .addMethod(
            getUpdateProprietaireMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireUpdateRequest,
                fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse>(
                  this, METHODID_UPDATE_PROPRIETAIRE)))
          .addMethod(
            getDeleteProprietaireMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId,
                fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireEtat>(
                  this, METHODID_DELETE_PROPRIETAIRE)))
          .build();
    }
  }

  /**
   */
  public static final class ImmatriculationServiceStub extends io.grpc.stub.AbstractStub<ImmatriculationServiceStub> {
    private ImmatriculationServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ImmatriculationServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ImmatriculationServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ImmatriculationServiceStub(channel, callOptions);
    }

    /**
     */
    public void proprietaires(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesRequest request,
        io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getProprietairesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void proprietaire(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId request,
        io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getProprietaireMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void nouveauProprietaire(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireRequest request,
        io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getNouveauProprietaireMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateProprietaire(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireUpdateRequest request,
        io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getUpdateProprietaireMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteProprietaire(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId request,
        io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireEtat> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getDeleteProprietaireMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class ImmatriculationServiceBlockingStub extends io.grpc.stub.AbstractStub<ImmatriculationServiceBlockingStub> {
    private ImmatriculationServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ImmatriculationServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ImmatriculationServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ImmatriculationServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesResponse proprietaires(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesRequest request) {
      return blockingUnaryCall(
          getChannel(), getProprietairesMethod(), getCallOptions(), request);
    }

    /**
     */
    public fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse proprietaire(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId request) {
      return blockingUnaryCall(
          getChannel(), getProprietaireMethod(), getCallOptions(), request);
    }

    /**
     */
    public fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse nouveauProprietaire(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireRequest request) {
      return blockingUnaryCall(
          getChannel(), getNouveauProprietaireMethod(), getCallOptions(), request);
    }

    /**
     */
    public fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse updateProprietaire(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireUpdateRequest request) {
      return blockingUnaryCall(
          getChannel(), getUpdateProprietaireMethod(), getCallOptions(), request);
    }

    /**
     */
    public fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireEtat deleteProprietaire(fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId request) {
      return blockingUnaryCall(
          getChannel(), getDeleteProprietaireMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class ImmatriculationServiceFutureStub extends io.grpc.stub.AbstractStub<ImmatriculationServiceFutureStub> {
    private ImmatriculationServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ImmatriculationServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ImmatriculationServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ImmatriculationServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesResponse> proprietaires(
        fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getProprietairesMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> proprietaire(
        fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId request) {
      return futureUnaryCall(
          getChannel().newCall(getProprietaireMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> nouveauProprietaire(
        fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getNouveauProprietaireMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse> updateProprietaire(
        fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireUpdateRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getUpdateProprietaireMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireEtat> deleteProprietaire(
        fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId request) {
      return futureUnaryCall(
          getChannel().newCall(getDeleteProprietaireMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_PROPRIETAIRES = 0;
  private static final int METHODID_PROPRIETAIRE = 1;
  private static final int METHODID_NOUVEAU_PROPRIETAIRE = 2;
  private static final int METHODID_UPDATE_PROPRIETAIRE = 3;
  private static final int METHODID_DELETE_PROPRIETAIRE = 4;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final ImmatriculationServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(ImmatriculationServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_PROPRIETAIRES:
          serviceImpl.proprietaires((fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesRequest) request,
              (io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietairesResponse>) responseObserver);
          break;
        case METHODID_PROPRIETAIRE:
          serviceImpl.proprietaire((fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId) request,
              (io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse>) responseObserver);
          break;
        case METHODID_NOUVEAU_PROPRIETAIRE:
          serviceImpl.nouveauProprietaire((fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireRequest) request,
              (io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse>) responseObserver);
          break;
        case METHODID_UPDATE_PROPRIETAIRE:
          serviceImpl.updateProprietaire((fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireUpdateRequest) request,
              (io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireResponse>) responseObserver);
          break;
        case METHODID_DELETE_PROPRIETAIRE:
          serviceImpl.deleteProprietaire((fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireId) request,
              (io.grpc.stub.StreamObserver<fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.ProprietaireEtat>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class ImmatriculationServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ImmatriculationServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("ImmatriculationService");
    }
  }

  private static final class ImmatriculationServiceFileDescriptorSupplier
      extends ImmatriculationServiceBaseDescriptorSupplier {
    ImmatriculationServiceFileDescriptorSupplier() {}
  }

  private static final class ImmatriculationServiceMethodDescriptorSupplier
      extends ImmatriculationServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    ImmatriculationServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ImmatriculationServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ImmatriculationServiceFileDescriptorSupplier())
              .addMethod(getProprietairesMethod())
              .addMethod(getProprietaireMethod())
              .addMethod(getNouveauProprietaireMethod())
              .addMethod(getUpdateProprietaireMethod())
              .addMethod(getDeleteProprietaireMethod())
              .build();
        }
      }
    }
    return result;
  }
}
