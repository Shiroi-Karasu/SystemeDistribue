package fs.iaad.immatriculation.mappers;

import fs.iaad.immatriculation.dto.VehiculeRequestDTO;
import fs.iaad.immatriculation.dto.VehiculeResponseDTO;
import fs.iaad.immatriculation.entities.Vehicule;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

@Component
public class VehiculeMapper {

    public VehiculeResponseDTO fromVehicule(Vehicule vehicule) {
        VehiculeResponseDTO vehiculeResponseDTO = new VehiculeResponseDTO();
        BeanUtils.copyProperties(vehicule, vehiculeResponseDTO);
        return vehiculeResponseDTO;
    }

    public Vehicule fromVehiculeDto(VehiculeRequestDTO vehiculeRequestDTO) {
        return Vehicule.builder()
                .numeroMatriculation(vehiculeRequestDTO.getNumeroMatriculation())
                .marque(vehiculeRequestDTO.getMarque())
                .modele(vehiculeRequestDTO.getModele())
                .puissanceFiscale(vehiculeRequestDTO.getPuissanceFiscale())
                .build();
    }

    public VehiculeResponseDTO updateVehicule(Vehicule oldVehicule, VehiculeRequestDTO vehiculeRequestDTO) {
        if (vehiculeRequestDTO.getNumeroMatriculation() != null)
            if (!vehiculeRequestDTO.getNumeroMatriculation().equals(oldVehicule.getNumeroMatriculation()))
                oldVehicule.setNumeroMatriculation(vehiculeRequestDTO.getNumeroMatriculation());
        if (vehiculeRequestDTO.getPuissanceFiscale() != null)
            if (!vehiculeRequestDTO.getPuissanceFiscale().equals(oldVehicule.getPuissanceFiscale()))
                oldVehicule.setPuissanceFiscale(vehiculeRequestDTO.getPuissanceFiscale());
        return fromVehicule(oldVehicule);
    }
}
