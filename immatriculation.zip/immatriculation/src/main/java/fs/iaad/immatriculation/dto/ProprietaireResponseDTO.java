package fs.iaad.immatriculation.dto;

import lombok.*;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class ProprietaireResponseDTO {
    Long id;
    String nom;
    Date dateNaissance;
    String mail;
}
