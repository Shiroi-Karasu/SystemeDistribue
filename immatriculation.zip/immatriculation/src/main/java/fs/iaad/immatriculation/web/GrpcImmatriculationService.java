package fs.iaad.immatriculation.web;

import fs.iaad.immatriculation.service.ProprietaireService;
import fs.iaad.immatriculation.service.VehiculeService;
import fs.iaad.immatriculation.stub.ImmatriculationServiceGrpc;
import fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;

@GrpcService
public class GrpcImmatriculationService extends ImmatriculationServiceGrpc.ImmatriculationServiceImplBase {
    private final ProprietaireService proprietaireService;
    private final VehiculeService vehiculeService;

    public GrpcImmatriculationService(ProprietaireService proprietaireService, VehiculeService vehiculeService) {
        this.proprietaireService = proprietaireService;
        this.vehiculeService = vehiculeService;
    }

    @Override
    public void proprietaires(ImmatriculationServiceOuterClass.ProprietairesRequest request, StreamObserver<ImmatriculationServiceOuterClass.ProprietairesResponse> responseObserver) {
        super.proprietaires(request, responseObserver);
    }

    @Override
    public void proprietaire(ImmatriculationServiceOuterClass.ProprietaireId request, StreamObserver<ImmatriculationServiceOuterClass.ProprietaireResponse> responseObserver) {
        super.proprietaire(request, responseObserver);
    }

    @Override
    public void nouveauProprietaire(ImmatriculationServiceOuterClass.ProprietaireRequest request, StreamObserver<ImmatriculationServiceOuterClass.ProprietaireResponse> responseObserver) {
        super.nouveauProprietaire(request, responseObserver);
    }

    @Override
    public void updateProprietaire(ImmatriculationServiceOuterClass.ProprietaireUpdateRequest request, StreamObserver<ImmatriculationServiceOuterClass.ProprietaireResponse> responseObserver) {
        super.updateProprietaire(request, responseObserver);
    }

    @Override
    public void deleteProprietaire(ImmatriculationServiceOuterClass.ProprietaireId request, StreamObserver<ImmatriculationServiceOuterClass.ProprietaireEtat> responseObserver) {
        super.deleteProprietaire(request, responseObserver);
    }
}
