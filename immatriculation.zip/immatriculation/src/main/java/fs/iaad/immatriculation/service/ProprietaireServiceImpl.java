package fs.iaad.immatriculation.service;

import fs.iaad.immatriculation.dto.ProprietaireRequestDTO;
import fs.iaad.immatriculation.dto.ProprietaireResponseDTO;
import fs.iaad.immatriculation.entities.Proprietaire;
import fs.iaad.immatriculation.mappers.ProprietaireMapper;
import fs.iaad.immatriculation.repositories.ProprietaireRepository;
import fs.iaad.immatriculation.stub.ImmatriculationServiceOuterClass;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class ProprietaireServiceImpl implements ProprietaireService{
    private final ProprietaireRepository proprietaireRepository;
    private final ProprietaireMapper proprietaireMapper;

    public ProprietaireServiceImpl(ProprietaireRepository proprietaireRepository, ProprietaireMapper proprietaireMapper) {
        this.proprietaireRepository = proprietaireRepository;
        this.proprietaireMapper = proprietaireMapper;
    }

    @Override
    public List<ProprietaireResponseDTO> allProprietaires() {
        List<ProprietaireResponseDTO> proprietairesDTO = new ArrayList<>();
        List<Proprietaire> proprietaires = proprietaireRepository.findAll();

        for (Proprietaire p: proprietaires) {
            proprietairesDTO.add(proprietaireMapper.fromProprietaire(p));
        }
        return proprietairesDTO;
    }

    @Override
    public List<ImmatriculationServiceOuterClass.ProprietairesResponse> allProprietairesResponse(List<ProprietaireResponseDTO> proprietairesDto) {
        List<ImmatriculationServiceOuterClass.ProprietairesResponse> proprietairesResponse = new ArrayList<>();
        for (ProprietaireResponseDTO p:proprietairesDto) {
            //proprietairesResponse.add();
        }
        return proprietairesResponse;
    }

    @Override
    public ProprietaireResponseDTO findProprietaireById(Long id) {
        return proprietaireMapper.fromProprietaire(proprietaireRepository.findById(id).orElseThrow(()-> new RuntimeException("Ce proprietaire est introuvable.")));
    }

    @Override
    public ProprietaireResponseDTO addProprietaire(ProprietaireRequestDTO proprietaireDTO) {
        Proprietaire nouveauProprietaire =proprietaireMapper.fromProprietaireDto(proprietaireDTO);
        proprietaireRepository.save(nouveauProprietaire);
        return proprietaireMapper.fromProprietaire(nouveauProprietaire);
    }

    @Override
    public ProprietaireResponseDTO updateProprietaire(Long id, ProprietaireRequestDTO proprietaireDTO) {
        Proprietaire oldProprietaire = proprietaireRepository.findById(id).orElseThrow(()-> new RuntimeException("Proprietaire introuvable"));
        return proprietaireMapper.updateProprietaireDTO(oldProprietaire, proprietaireDTO);
    }

    @Override
    public void deleteProprietaire(Long id) {
        proprietaireRepository.deleteById(id);
    }
}
