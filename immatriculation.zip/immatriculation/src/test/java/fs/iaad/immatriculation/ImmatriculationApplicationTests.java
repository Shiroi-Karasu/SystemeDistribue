package fs.iaad.immatriculation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImmatriculationApplicationTests {

	@Test
	void contextLoads() {
	}

}
