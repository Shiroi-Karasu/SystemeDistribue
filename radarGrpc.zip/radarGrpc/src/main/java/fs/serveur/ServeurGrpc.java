package fs.serveur;

import fs.service.GrpcRadarService;
import io.grpc.Server;
import io.grpc.ServerBuilder;

import java.io.IOException;

public class ServeurGrpc {
    public static void main(String[] args) {
        //créer un serveur GRPC
        Server serveur = ServerBuilder.forPort(1233) //Spécification du port de serveur
                .addService(new GrpcRadarService()) //publier le webservice
                .build();
        try {
            serveur.start(); //lancer le serveur
            serveur.awaitTermination(); //Attedre la terminisant de l'application
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
