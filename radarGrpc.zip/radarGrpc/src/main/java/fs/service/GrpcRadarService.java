package fs.service;

import fs.radarStub.RadarServiceGrpc;
import fs.radarStub.RadarServiceOuterClass;
import io.grpc.stub.StreamObserver;

import java.util.Random;

public class GrpcRadarService extends RadarServiceGrpc.RadarServiceImplBase {
    @Override
    public void nouveauDepassement(RadarServiceOuterClass.DepassementRequest request, StreamObserver<RadarServiceOuterClass.DepassementResponse> responseObserver) {
        int vitesseMax = request.getVitesseMaximale();
        int puissanceFiscale = request.getPuissanceFiscale();

        RadarServiceOuterClass.DepassementResponse response = RadarServiceOuterClass.DepassementResponse.newBuilder()
                        .setVitesseVehicule(new Random().nextInt(vitesseMax, puissanceFiscale + 1))
                        .build();//pas de new() <= objet non modifiable.

        responseObserver.onNext(response); //envoyer un item.
        responseObserver.onCompleted(); //indiquer au client que c'est terminé.
    }
}
